c
      integer maxnrec
      character*10  magic_str
      parameter (maxnrec=200)
      parameter (magic_str='LOG_RECORD')

      integer nrecords
      character*79 info(maxnrec)

      common /log_int/ nrecords
      common /log_str/ info

      save /log_int/, /log_str/
c------------------------------------
